<footer>

    <center>

        <p>
            © 2026 CBI BOOKMART
        </p>

        <p>
            Belanja Buku Mudah dan Cepat
        </p>

    </center>

</footer>