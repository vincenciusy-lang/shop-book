<?php

if (session_status() === PHP_SESSION_NONE) {

    session_start();
}

?>

<nav class="navbar">

    <div class="logo">

        📚 CBI BOOKMART

    </div>

    <ul class="nav-menu">

        <li>

            <a href="../user/index.php">

                Home

            </a>

        </li>

        <li>

            <a href="../user/katalog.php">

                Katalog

            </a>

        </li>

        <li>

            <a href="../user/about.php">

                About

            </a>

        </li>

        <li>

            <a href="../user/contact.php">

                Contact

            </a>

        </li>

        <li>

            <a href="../user/pesan_saya.php">

                Pesan Saya

            </a>

        </li>

        <?php if (isset($_SESSION['role']) && $_SESSION['role'] == "user") { ?>

            <li>

                <a href="../logout.php">

                    Logout

                </a>

            </li>

        <?php } else { ?>

            <li>

                <a href="../login.php">

                    Login

                </a>

            </li>

        <?php } ?>

    </ul>

</nav>