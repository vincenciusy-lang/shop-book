<?php

session_start();

include "../config/koneksi.php";

if (!isset($_SESSION['role']) || $_SESSION['role'] != "admin") {

    header("location:../login.php");
    exit;
}

$data = mysqli_query(
    $conn,

    "SELECT * FROM users ORDER BY id_user DESC"

);

?>

<!DOCTYPE html>

<html>

<head>

    <title>
        Data User
    </title>

    <link rel="stylesheet" href="../css/style.css">

</head>

<body>

    <?php include "../template/sidebar.php"; ?>

    <div class="content">

        <h1>
            Data User
        </h1>

        <p>
            Daftar pengguna yang terdaftar pada CBI BOOKMART
        </p>

        <div class="table-box">

            <table width="100%">

                <tr>

                    <th>
                        No
                    </th>

                    <th>
                        Nama
                    </th>

                    <th>
                        Email
                    </th>

                    <th>
                        Alamat
                    </th>

                    <th>
                        Role
                    </th>

                    <th>
                        Aksi
                    </th>

                </tr>

                <?php

                $no = 1;

                while ($row = mysqli_fetch_assoc($data)) {

                ?>

                    <tr>

                        <td>

                            <?= $no++; ?>

                        </td>

                        <td>

                            <?= $row['nama']; ?>

                        </td>

                        <td>

                            <?= $row['email']; ?>

                        </td>

                        <td>

                            <?= $row['alamat']; ?>

                        </td>

                        <td>

                            <?php if ($row['role'] == "admin") { ?>

                                <span class="badge-selesai">

                                    Admin

                                </span>

                            <?php } else { ?>

                                <span class="badge-proses">

                                    User

                                </span>

                            <?php } ?>

                        </td>

                        <td>

                            <?php if ($row['role'] != "admin") { ?>

                                <a

                                    href="hapus_user.php?id=<?= $row['id_user']; ?>"

                                    class="btn-hapus"

                                    onclick="return confirm('Yakin ingin menghapus user ini?')">

                                    Hapus

                                </a>

                            <?php } else { ?>

                                -

                            <?php } ?>

                        </td>

                    </tr>

                <?php } ?>

            </table>

        </div>

    </div>

</body>

</html>