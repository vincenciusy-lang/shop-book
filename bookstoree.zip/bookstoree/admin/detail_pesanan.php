<?php

session_start();

include "../config/koneksi.php";

if (!isset($_SESSION['role']) || $_SESSION['role'] != "admin") {

    header("location:../login.php");

    exit;
}

if (!isset($_GET['id'])) {

    header("location:pesanan.php");

    exit;
}

$id_pesanan = $_GET['id'];

$data = mysqli_query(
    $conn,

    "

SELECT 

pesanan.*,

users.nama

FROM pesanan

INNER JOIN users

ON pesanan.id_user = users.id_user

WHERE id_pesanan='$id_pesanan'

"

);

$pesanan = mysqli_fetch_assoc($data);

$detail = mysqli_query(
    $conn,

    "

SELECT

detail_pesanan.*,

buku.judul_buku,

buku.penulis,

buku.harga,

buku.gambar

FROM detail_pesanan

INNER JOIN buku

ON detail_pesanan.id_buku=buku.id_buku

WHERE detail_pesanan.id_pesanan='$id_pesanan'

"

);

?>

<!DOCTYPE html>

<html>

<head>

    <title>

        Detail Pesanan

    </title>

    <link rel="stylesheet" href="../css/style.css">

</head>

<body>

    <?php include "../template/sidebar.php"; ?>

    <div class="content">

        <h1>

            Detail Pesanan #<?= $id_pesanan; ?>

        </h1>

        <div class="order-card">

            <h2>

                Data Pembeli

            </h2>

            <p>

                Nama User :

                <b>

                    <?= $pesanan['nama']; ?>

                </b>

            </p>

            <p>

                Tanggal :

                <b>

                    <?= $pesanan['tanggal']; ?>

                </b>

            </p>

            <p>

                Metode Pembayaran :

                <b>

                    <?= $pesanan['metode_pembayaran']; ?>

                </b>

            </p>

            <p>

                Status Pembayaran :

                <b>

                    <?= $pesanan['status_pembayaran']; ?>

                </b>

            </p>

            <p>

                Status Pesanan :

                <b>

                    <?= $pesanan['status']; ?>

                </b>

            </p>

            <hr>

            <h2>

                Daftar Buku

            </h2>

            <?php while ($row = mysqli_fetch_assoc($detail)) { ?>

                <div class="book-order">

                    <img src="../images/buku/<?= $row['gambar']; ?>">

                    <div>

                        <h3>

                            <?= $row['judul_buku']; ?>

                        </h3>

                        <p>

                            Penulis :

                            <?= $row['penulis']; ?>

                        </p>

                        <p>

                            Jumlah :

                            <?= $row['jumlah']; ?>

                        </p>

                        <p>

                            Harga :

                            <b>

                                Rp <?= number_format($row['harga'], 0, ',', '.'); ?>

                            </b>

                        </p>

                    </div>

                </div>

            <?php } ?>

            <br>

            <a href="pesanan.php" class="btn">

                Kembali

            </a>

        </div>

    </div>

</body>

</html>