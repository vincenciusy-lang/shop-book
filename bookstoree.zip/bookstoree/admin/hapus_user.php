<?php

session_start();

include "../config/koneksi.php";

if (!isset($_SESSION['role']) || $_SESSION['role'] != "admin") {

    header("location:../login.php");

    exit;
}

$id = $_GET['id'];

$query = mysqli_query(
    $conn,

    "DELETE FROM users WHERE id_user='$id'"

);

if ($query) {

    echo "

<script>

alert('User berhasil dihapus');

window.location='user.php';

</script>

";
} else {

    echo "

<script>

alert('User gagal dihapus');

window.location='user.php';

</script>

";
}
