<?php
include "config/koneksi.php";
$data = mysqli_query(
    $conn,
    "SELECT buku.*, kategori.nama_kategori
    FROM buku
    INNER JOIN kategori
    ON buku.id_kategori = kategori.id_kategori
    ORDER BY buku.id_buku DESC"
);
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0">
    <title>
        Katalog Buku | CBI
    </title>
    <link
        rel="stylesheet"
        href="css/style.css">
</head>

<body>
    <!-- =========================
NAVBAR
========================= -->
    <nav class="navbar">
        <div class="logo">
            📚 CBI
        </div>
        <ul class="nav-menu">
            <li>
                <a href="index.php">
                    Home
                </a>
            </li>

            <li>
                <a href="katalog.php">
                    Katalog
                </a>
            </li>

            <li>
                <a href="login.php">
                    Login
                </a>
            </li>

            <li>
                <a href="register.php">
                    Register
                </a>
            </li>

        </ul>
    </nav>
    <!-- =========================
KONTEN KATALOG
========================= -->
    <div class="content-user">
        <h1>
            Katalog Buku
        </h1>
        <p>
            Temukan berbagai koleksi buku terbaik CBI
        </p>
        <div class="book-container">
            <?php while ($row = mysqli_fetch_assoc($data)) { ?>
                <div class="book-card">
                    <!-- GAMBAR BUKU -->
                    <?php if (!empty($row['gambar'])) { ?>
                        <img
                            src="images/buku/<?= htmlspecialchars($row['gambar']); ?>"
                            alt="<?= htmlspecialchars($row['judul_buku']); ?>">
                    <?php } else { ?>
                        <img
                            src="images/no-image.png"
                            alt="Gambar buku tidak tersedia">
                    <?php } ?>
                    <!-- JUDUL BUKU -->
                    <h3>
                        <?= htmlspecialchars($row['judul_buku']); ?>
                    </h3>

                    <!-- PENULIS -->
                    <p>
                        Penulis:
                        <?= htmlspecialchars($row['penulis']); ?>
                    </p>

                    <!-- KATEGORI -->
                    <p>
                        Kategori:
                        <?= htmlspecialchars($row['nama_kategori']); ?>
                    </p>

                    <!-- HARGA -->
                    <h4>
                        Rp
                        <?= number_format(
                            $row['harga'],
                            0,
                            ',',
                            '.'
                        ); ?>
                    </h4>

                    <!-- BUTTON BELI -->
                    <a
                        href="login.php"
                        class="btn">
                        Beli Buku
                    </a>
                </div>

            <?php } ?>
        </div>
    </div>
</body>

</html>