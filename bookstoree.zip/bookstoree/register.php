<?php

include "config/koneksi.php";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $nama = trim($_POST['nama']);
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);
    $alamat = trim($_POST['alamat']);

    // Mengamankan input
    $nama = mysqli_real_escape_string($conn, $nama);
    $email = mysqli_real_escape_string($conn, $email);
    $password = mysqli_real_escape_string($conn, $password);
    $alamat = mysqli_real_escape_string($conn, $alamat);

    // Cek apakah email sudah pernah digunakan
    $cek_email = mysqli_query(
        $conn,
        "SELECT id_user FROM users WHERE email='$email'"
    );

    if (mysqli_num_rows($cek_email) > 0) {

        echo "
        <script>
            alert('Email sudah terdaftar. Silakan gunakan email lain.');
        </script>
        ";
    } else {

        // Simpan akun baru
        $query = mysqli_query(
            $conn,
            "INSERT INTO users
            (nama, email, password, alamat, role)
            VALUES
            ('$nama', '$email', '$password', '$alamat', 'user')"
        );

        if ($query) {

            echo "
            <script>
                alert('Registrasi berhasil. Silakan login.');
                window.location='login.php';
            </script>
            ";

            exit;
        } else {

            // Jika gagal, tampilkan penyebabnya
            die("Registrasi gagal: "
                . mysqli_error($conn));
        }
    }
}

?>

<!DOCTYPE html>
<html lang="id">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0">

    <title>Daftar Akun CBI BOOKMART</title>

    <link rel="stylesheet" href="css/style.css">

</head>

<body>

    <div class="register-container">

        <div class="register-card">

            <div class="register-header">

                <h1>📚 CBI BOOKMART</h1>

                <h2>Daftar Akun Baru</h2>

                <p>
                    Buat akun untuk mulai berbelanja buku favorit Anda
                </p>

            </div>

            <form method="POST" action="">

                <div class="input-group">

                    <label>Nama Lengkap</label>

                    <input
                        type="text"
                        name="nama"
                        placeholder="Masukkan nama lengkap"
                        required>

                </div>

                <div class="input-group">

                    <label>Email</label>

                    <input
                        type="email"
                        name="email"
                        placeholder="Masukkan email"
                        required>

                </div>

                <div class="input-group">

                    <label>Password</label>

                    <input
                        type="password"
                        name="password"
                        placeholder="Masukkan password"
                        required>

                </div>

                <div class="input-group">

                    <label>Alamat Lengkap</label>

                    <textarea
                        name="alamat"
                        placeholder="Masukkan alamat lengkap"
                        required></textarea>

                </div>

                <button
                    type="submit"
                    class="btn-register">
                    Daftar Sekarang
                </button>

                <div class="login-link">

                    Sudah punya akun?

                    <a href="login.php">
                        Login disini
                    </a>

                </div>

            </form>

        </div>

    </div>

</body>

</html>